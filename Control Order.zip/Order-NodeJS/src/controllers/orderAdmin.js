const OrderAdmServices = require('../services/orderAdmin');

module.exports = {
  async index(req, res) {
    try {
      const sort = await OrderAdmServices.index();
      return res.status(200).json(sort);
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message + err.stack });
    }
  },
  async find(req, res) {
    try {
      const readFile = await OrderAdmServices.find(req);
      return res.status(200).json(JSON.parse(readFile));

    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
  async store(req, res) {
    try {
      await OrderAdmServices.startDay();
      return res.status(200).json({ mensagem: 'Dia Iniciado!' });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
  async status(req, res) {
    try {
      const result = await OrderAdmServices.status(req);
      return res.status(result.status).json({ mensagem: result.msg, ext: req.params });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
  async cancelItem(req, res) {
    try {
      const result = await OrderAdmServices.cancelItem(req);
      return res.status(result.status).json({ mensagem: result.msg });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
}