const SettingsServices = require('../services/settings');

module.exports = {
  async auth(req, res) {
    try {
      const hasAuth = await SettingsServices.auth(req);
      return res.status(hasAuth.status).json({ mensagem: hasAuth.msg });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message + err.stack });
    }
  },
  async index(req, res) {
    try {
      const readFile = await SettingsServices.index();
      return res.status(200).json(JSON.parse(readFile));
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message + err.stack });
    }
  },
  async store(req, res) {
    try {
      const result = await SettingsServices.store(req);
      return res.status(result.status).json({ mensagem: result.msg });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message + err.stack });
    }
  },
}