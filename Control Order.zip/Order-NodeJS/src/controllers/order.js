const OrderServices = require('../services/order');

module.exports = {
  async index(req, res) {
    try {
      const readFile = await OrderServices.index();
      return res.status(200).json(JSON.parse(readFile.content));
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
  async store(req, res) {
    try {
      const result = await OrderServices.store(req);
      return res.status(result.status).json({ mensagem: result.msg });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
  async resume(req, res) {
    try {
      const result = await OrderServices.resume(req);
      return res.status(result.status).json({ content: result.content });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
}