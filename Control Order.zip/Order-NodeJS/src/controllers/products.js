const ProductServices = require('../services/products');

module.exports = {
  async index(req, res) {
    try {
      const readFile = await ProductServices.index();
      return res.status(200).json(JSON.parse(readFile));
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
  async store(req, res) {
    try {
      const result = await ProductServices.store(req);
      return res.status(result.status).json({ mensagem: result.msg });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
  async update(req, res) {
    try {
      const result = await ProductServices.update(req);
      return res.status(result.status).json({ mensagem: result.msg });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
  async destroy(req, res) {
    try {
      const result = await ProductServices.delete(req);
      return res.status(result.status).json({ mensagem: result.msg });
    } catch (err) {
      console.error(err.stack);
      return res.status(500).json({ mensagem: 'Erro interno -> ' + err.message });
    }
  },
}