module.exports = {
  common() { return './src/database' },
  getDate(less = 0) {
    return new Date(Date.now() - (less * 24 * 60 * 60 * 1000))
  },
  formatDate(day) {
    const that = require('./common.js');
    return that.getDate(day).toLocaleString().slice(0, 10).split('/').reverse().join('-')
  },
  formatTime(day) {
    const year = new Date(day).toLocaleString().slice(0, 10).split('/').reverse().join('-');
    const time = new Date(day).toLocaleString().slice(-8);
    return `${year} ${time}`
  },
  formatHash(hash) {
    return Buffer.from(`${String(hash).split('').reverse().join('')}`, 'utf-8').toString('base64');
  }
};