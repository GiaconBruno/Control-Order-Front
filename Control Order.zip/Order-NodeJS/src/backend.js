const express = require('express');
const cors = require('cors');
const app = express();
const routes = require('./routes');
const { startDay } = require('./services/orderAdmin')

app.use(express.json());
app.use(cors());
app.use(routes);

console.log('Desenvolvido por: Bruno Giacon');

app.listen(3000, startDay());