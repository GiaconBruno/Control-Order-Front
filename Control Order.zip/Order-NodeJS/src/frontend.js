const express = require("express");
var cons = require('consolidate');
var path = '../Order-Front';

app = express();
app.engine('html', cons.swig);
app.set('view engine', 'html');
app.set('views', `${path}/`);

app.use('/', express.static(`${path}/src`));

app.get('/', function (req, res) {
    res.render('index')
});
app.listen(8080);