const { readdirSync, readFileSync, writeFileSync } = require('fs');
const { common, formatDate } = require('../settings/common.js');
const path = `${common()}/orders`;
const statusValid = ['started', 'preparing', 'canceled', 'paid', 'deleted']

const getFile = (date) => `${path}/${date}.json`

module.exports = {
  startDay() {
    const list = readdirSync(path, 'utf-8');
    const find = list.findIndex(l => l.slice(0, 10) == formatDate());

    if (find == -1) writeFileSync(getFile(formatDate()), JSON.stringify([]))
    console.log('Servidor: Dia Iniciado!');
  },
  index() {
    const list = readdirSync(path, 'utf-8');
    validStatus = ['started', 'preparing', 'paid']
    let array = [];
    list.map(l => {
      let qtd = 0;
      let total = 0;
      const content = Array.from(JSON.parse(readFileSync(`${path}/${l}`, 'utf-8'))).sort().reverse()
      content.map(c => {
        if (c.status != 'deleted') qtd++;
        if (validStatus.includes(c.status))
          total += c.products.reduce((sum, item) => (item.status) ? (sum + parseFloat(item.valor)) : sum, 0)
      })
      if ((qtd && (l!='example.json')) || ((!array.length) && (l=='example.json'))) array.unshift({ file: l.slice(0, -5), qtd, total })
    });

    return array;
  },
  find(req) {
    let archive = '';
    let list = '';

    if (req.query && req.query.data)
      archive = getFile(req.query.data);

    if (!archive) {
      list = readdirSync(path, 'utf-8');
      archive = `${path}/${list.sort().reverse()[0]}`;
    }

    return readFileSync(archive, 'utf-8');
  },
  status(req) {
    if (!req.params.hash) return { status: 400, msg: "Pedido não encontrado! (hash)" };
    if (!statusValid.includes(req.params.status)) return { status: 404, msg: "Status Inválido!" };

    const file = this.find(req);
    const orders = Array.from(JSON.parse(file));

    const pos = orders.findIndex(order => ((order.hash == req.params.hash)));
    if (pos == -1) return { status: 400, msg: "Pedido não encontrado!" };

    orders[pos].status = req.params.status;
    orders[pos].products.map(p => parseFloat(p.valor))

    let fileUpdate = '';
    if (req.query.data) fileUpdate = getFile(req.query.data);
    else fileUpdate = readdirSync(path, 'utf-8').sort().reverse()[0];

    writeFileSync(fileUpdate, JSON.stringify(orders));
    return { status: 200, msg: "Status Alterado!" };
  },
  cancelItem(req) {
    if (!req.params.hash) return { status: 400, msg: "Pedido não encontrado! (hash)" };

    const file = this.find(req);
    const orders = Array.from(JSON.parse(file));

    const posHash = orders.findIndex(order => (order.hash == req.params.hash));
    if (posHash == -1) return { status: 400, msg: "Pedido não encontrado!" };

    const posItem = (orders[posHash].products).findIndex(item => (item.hashItem == req.params.hashItem));
    if (posItem == -1) return { status: 400, msg: "Item não encontrado!" };

    if (['canceled', 'paid', 'deleted'].includes(orders[posHash].status))
      return { status: 200, msg: "Cancelamento NÃO realizado! (Status)" };


    if (!orders[posHash].products[posItem].status)
      return { status: 200, msg: "Cancelamento NÃO realizado! (StatusItem)" };

    orders[posHash].products[posItem].status = false;

    let fileUpdate = '';
    if (req.query.data) fileUpdate = getFile(req.query.data);
    else fileUpdate = readdirSync(path, 'utf-8').sort().reverse()[0];

    writeFileSync(fileUpdate, JSON.stringify(orders));
    return { status: 200, msg: "Item Cancelado!" };
  },
}