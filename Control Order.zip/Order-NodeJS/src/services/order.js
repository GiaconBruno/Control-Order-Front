const { readdirSync, readFileSync, writeFileSync } = require('fs');
const { common, formatTime, formatHash } = require('../settings/common.js');
const path = `${common()}/orders`;

module.exports = {
  index() {
    const list = readdirSync(path, 'utf-8');
    const archive = list.filter(f => f != 'example.json').sort().reverse()[0];
    return {
      file: archive,
      content: readFileSync(`${path}/${archive}`, 'utf-8')
    };
  },
  store(req) {
    req.body.hash = formatHash(Date.now());
    req.body.status = "started";
    if (!req.body && !req.body.name && !req.body.device)
      return { status: 400, msg: "Preencha Todos os Campos!" };

    if (!req.body && !(req.body.products).length)
      return { status: 400, msg: "Nenhum Item Incluido!" };

    const itens = [];
    req.body.products.map((p, y) => {
      const newHash = Date.now();
      Array.from({ length: p.qtd }).map((i, x) =>
        itens.push({
          hashItem: formatHash(newHash - ((100 * y) + x)),
          qtd: 1,
          descricao: p.descricao,
          valor: parseFloat(p.valor),
          time: formatTime(Date.now()),
          status: true
        }))
    });

    req.body.products = itens;
    const scan = this.index();
    const newContent = JSON.parse(scan.content);
    newContent.unshift(req.body);

    writeFileSync(`${path}/${scan.file}`, JSON.stringify(newContent));
    return { status: 200, msg: "Pedido Realizado!" };

  },
  resume(req) {
    const list = readdirSync(path, 'utf-8');
    const statusValid = ['started', 'preparing', 'canceled', 'paid']
    const allOrders = [];

    list.filter(f => f != 'example.json').reverse().map(o => {
      const content = readFileSync(`${path}/${o}`, 'utf-8')
      const prod = [];
      const total = { qtd: 0, valor: 0 };
      const pending = { qtd: 0, valor: 0 };
      Array.from(JSON.parse(content)).map(i => {
        if (i.device == req.query.disp && statusValid.includes(i.status)) {
          i.products.map(p => {
            let modifyStatus = (['started', 'preparing'].includes(i.status)) ? 'preparing' : i.status;
            if (!p.status) modifyStatus = 'canceled';
            const pos = prod.findIndex(item => (item.descricao == p.descricao) && (item.status == modifyStatus));

            if (pos == -1) prod.push({
              qtd: parseFloat(p.qtd),
              descricao: p.descricao,
              valor: parseFloat(p.valor),
              status: modifyStatus
            })
            else {
              prod[pos].qtd += parseFloat(p.qtd);
              prod[pos].valor += parseFloat(p.valor)
            }

            if (modifyStatus == 'paid') {
              total.qtd += parseFloat(p.qtd)
              total.valor += parseFloat(p.valor)
            }
            if (modifyStatus == 'preparing') {
              pending.qtd += parseFloat(p.qtd)
              pending.valor += parseFloat(p.valor)
            }
          })
        }
      })
      if (prod.length) allOrders.push({
        time: o.slice(0, 10),
        products: prod,
        total,
        pending,
      })
    })

    return { status: 200, content: allOrders };
  }
}