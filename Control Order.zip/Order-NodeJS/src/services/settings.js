const { readFileSync, writeFileSync } = require('fs');
const { common } = require('../settings/common.js')
const path = `${common()}/settings.json`;

module.exports = {
  index() {
    try {
      return readFileSync(path, 'utf-8');
    } catch {
      writeFileSync(path, JSON.stringify([]));
      return readFileSync(path, 'utf-8');
    }
  },
  store(req) {
    const readFile = readFileSync(path, 'utf-8');
    let result = JSON.parse(readFile);

    result.image = (req.body.image).replace(/[^a-zA-Z0-9 ()]/g, '') || '';
    result.company = (req.body.company).replace(/[^a-zA-Z0-9 ()]/g, '');
    result.description = (req.body.description).replace(/[^a-zA-Z0-9 ()]/g, '');
    result.PIX = (req.body.PIX).replace(/[^a-zA-Z0-9 ()]/g, '');

    result = req.body;
    writeFileSync(path, JSON.stringify(result));
    return { status: 200, msg: "Atualizado com exito!" };
  },
}