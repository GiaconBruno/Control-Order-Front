const { readFileSync, writeFileSync } = require('fs');
const { common } = require('../settings/common.js')
const path = `${common()}/settings.json`;

module.exports = {
  auth(req) {
    const file = JSON.parse(readFileSync(path, 'utf-8'));
    console.log(file);
    if ([req.body.auth, '', null, undefined].includes(file.auth))
      return { status: 200, msg: "Acesso Permitido!" };
    else
      return { status: 401, msg: "Acesso Negado!" };
  },
  index() {
    try {
      return readFileSync(path, 'utf-8');
    } catch {
      writeFileSync(path, JSON.stringify([]));
      return readFileSync(path, 'utf-8');
    }
  },
  store(req) {
    const readFile = readFileSync(path, 'utf-8');
    let result = JSON.parse(readFile);

    result = req.body;
    writeFileSync(path, JSON.stringify(result));
    return { status: 200, msg: "Atualizado com exito!" };
  },
}