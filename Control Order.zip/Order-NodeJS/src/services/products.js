const { readFileSync, writeFileSync } = require('fs');
const { common, formatHash } = require('../settings/common.js')
const path = `${common()}/products.json`;

module.exports = {
  index() {
    try {
      return readFileSync(path, 'utf-8');
    } catch {
      writeFileSync(path, JSON.stringify([]));
      return readFileSync(path, 'utf-8');
    }
  },
  store(req) {
    const readFile = readFileSync(path, 'utf-8');
    const result = Array.from(JSON.parse(readFile));

    req.body.hash = formatHash(Date.now());
    req.body.estoque = parseFloat(req.body.estoque || 0);
    // req.body.descricao = (req.body.descricao).replace(/[^a-zA-Z0-9 ()]/g, '')
    req.body.valor = parseFloat(req.body.valor || 0)

    const valid = ((req.body.descricao).replace(/ /g, '') && req.body.valor)
    if (!valid) return { status: 400, msg: "Preencha todos os campos!" };

    const pos = result.findIndex(p => ((p.hash == req.body.hash) || (p.descricao.toLowerCase() == req.body.descricao.toLowerCase())));
    if (pos != -1) return { status: 400, msg: "Produto Duplicado!" };

    result.push(req.body);
    writeFileSync(path, JSON.stringify(result));
    return { status: 200, msg: "Cadastrado com exito!" };
  },
  update(req) {
    const readFile = readFileSync(path, 'utf-8');
    const result = Array.from(JSON.parse(readFile));

    req.body.hash = req.params.hash;
    // req.body.descricao = (req.body.descricao).replace(/[^a-zA-Z0-9 ()]/g, '')
    req.body.estoque = parseFloat(req.body.estoque || 0);
    req.body.valor = parseFloat(req.body.valor || 0)

    const valid = ((req.body.descricao).replace(/ /g, '') && req.body.valor)
    if (!valid) return { status: 400, msg: "Preencha todos os campos!" };

    const findHash = result.findIndex(p => p.hash == req.params.hash);
    if (findHash == -1) return { status: 400, msg: "Produto não encontrado!" };

    const findDesc = result.findIndex(p => (p.hash != req.params.hash) && (p.descricao == req.body.descricao));
    if (findDesc != -1) return { status: 400, msg: "Produto Duplicado (Descrição)!" };
    if ((req.params.hash).length < 13) req.body.hash = formatHash(Date.now());

    result[findHash] = req.body;
    writeFileSync(path, JSON.stringify(result));
    return { status: 200, msg: "Atualizado com exito!" };
  },
  delete(req) {
    const { hash } = req.params;
    const readFile = readFileSync(path, 'utf-8');
    const result = Array.from(JSON.parse(readFile));

    const pos = result.findIndex(p => p.hash == hash);
    if (pos == -1) return { status: 400, msg: "Produto não encontrado!" };

    let array = [];
    result.map(p => { if (p.hash != hash) array.push(p) });
    writeFileSync(path, JSON.stringify(array));
    return { status: 200, msg: "Deletado com exito!" };
  },
}