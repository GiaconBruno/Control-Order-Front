const express = require("express");
const routes = express.Router();
const ProductConrtoller = require('./controllers/products');
const SettingsController = require('./controllers/settings');
const OrderAdmController = require('./controllers/orderAdmin');
const OrderConrtoller = require('./controllers/order');
const { formatHash } = require('./settings/common.js')

routes.get("/", (req, res) => {
  return res.status(200).json(['Bem Vindo!', 'Servidor: Operacional', 'Developed by: Bruno Giacon', formatHash(Date.now())]);
});

// Auth
routes.post("/auth", SettingsController.auth);

// Products
routes.get("/api/products", ProductConrtoller.index);
routes.post("/api/product", ProductConrtoller.store);
routes.patch("/api/product/:hash", ProductConrtoller.update);
routes.delete("/api/product/:hash", ProductConrtoller.destroy);
// Settings
routes.get("/api/settings", SettingsController.index);
routes.post("/api/settings", SettingsController.store);
// Orders Adm
routes.get("/api/orders/list", OrderAdmController.index);
routes.get("/api/order", OrderAdmController.find);
routes.post("/api/order/start", OrderAdmController.store);
routes.post("/api/order/:hash/:status", OrderAdmController.status);
routes.delete("/api/order/:hash/:hashItem", OrderAdmController.cancelItem);
// Orders Common
routes.get("/api/client/orders", OrderConrtoller.index);
routes.get("/api/client/resume", OrderConrtoller.resume);
routes.post("/api/client/create", OrderConrtoller.store);

module.exports = routes;